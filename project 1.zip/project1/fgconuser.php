
<?php
  
  include("connection.php");

  if(isset($_POST['submit']))
{
   $username=$_POST['email'];
   $new_password=$_POST['new_psw'];
   $confirm_password=$_POST['con_psw'];

   $query="SELECT * FROM `registration1` WHERE `email`='$username' ";
   $query1=mysqli_query($link,$query);
   $row=mysqli_fetch_array($query1);
   $result=$row['email'];
   if($result === $username){

   	if($new_password === $confirm_password)
      {
         if(strlen($new_password)>25||strlen($new_password)<7){
           header("location:forgetpswadmin.php?error");

         }else{

   	  		$query2="UPDATE `registration1` SET `password`='$confirm_password' WHERE `email`='$username'";

          $con1 =mysqli_query($link,$query2);

            echo "<script>alert('Your pass has been changed');</script>";
         }
       }else
            echo "<script>alert('new password don't match');</script>";
        }else
        echo "<script>alert('username doesn't match');</script>";

      }
         ?>