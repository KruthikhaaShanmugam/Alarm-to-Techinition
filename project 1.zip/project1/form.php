<?php
  include("formcon.php");

  ?>
<html>
<head><form method = "POST">
	<style type="text/css">
		*{
			margin:0;
			padding:0;
		}
		body{
			background-image:url("https://media-exp1.licdn.com/dms/image/C4D1BAQGgMefwzW-fsw/company-background_10000/0/1585984596983?e=2159024400&v=beta&t=Csu-PrBPUnEmzE9S989_xriX0IVInRfQ5opGPu4tr4k");
			background-position: center;
			background-size:cover;
			font-family:bahnschrift;
			margin-top:40px;
		}
		.box {
			width: 850px;
			background-color: rgb(0,0,0,0.6);
			margin:auto;
			color: #FFFFFF;
			padding: 10px 0px 10px 0px;
			text-align: center;
			border-radius: 15px 15px 0px 0px;
		}
		.main
		{
			background-color: rgb(0,0,0,0.5);
			width: 850px;
			margin: auto;
		}
		form
		{
			padding: -25px;
		}
		#name
		{
			width: 100%;
			height:100px;
		}
		.name{
			margin-left: 75px;
			margin-top: 7px;
			width: 125px;
			color: white;
			font-size: 23px;
			font-weight: 700;
		}
		.firstname
		{
			position: relative;
			left: 250px;
			top:-34;
			line-height: 35px;
			border-radius: 6px;
			padding: 0 22px;
			font-size:16px;
		}
		.email
		{
			position: relative;
			left: 250px;
			top:-37;
			line-height: 35px;
			width: 532px;
			border-radius: 6px;
			padding: 0 22px;
			font-size:16px;
			color: #555;
		}
		.center {	
					position: relative;
			        left: -100px;
			        top:-34;
			        line-height: 75px;
			        font-size:16px;
					text-align: center;
				}


		.roomno
		{
			position: relative;
			left: 250px;
			top:-37;
			line-height: 35px;
			width: 532px;
			border-radius: 6px;
			padding: 0 22px;
			font-size:16px;
			color: #555;
		}
		.option
		{
			position: relative;
			left: 250px;
			top:-37;
			line-height: 40px;
			width: 532px;
			border-radius: 6px;
			padding: 0 22px;
			font-size:24px;
			color: #555;
			outline: none;
			overflow: hidden;
		}
		.dept
		{
			position: relative;
			left: 250px;
			top:-27;
			line-height: 45px;
			width: 532px;
			border-radius: 6px;
			padding: 0 22px;
			color: #555;
			font-size:24px;
			outline: none;
			overflow: hidden;
		}
		#textarea
		{
			margin-left: 25px;
			color: white;
		}
		.Complaint
		{
			position: relative;
			left: 250px;
			top:-37;
			line-height: 80px;
			width: 532px;
			border-radius: 6px;
			padding: 0 22px;
			font-size:16px;
			color: #555;
		}
		button
		{
			background-color:#339933 ;
			display:block;
			margin: 20px 0px 0px 20px;
			text-align: center;
			border-radius: 12px;
			font-family:bahnschrift;
			border: 2px solid #366473;
			padding: 12px 58px;
			font-size:24px;
			outline: none;
			color: white;
			cursor: pointer;
			transition: 0.25px;
		}
		button:hover
		{
			background-color: #00cc00;
		}
		.submit
		{
			position: relative;
			left: 250px;
			top:-34;
			line-height: 35px;
			border-radius: 4px;
			padding: 0 22px;
			font-size:16px;
		}


	</style>
</head>
<body>
	<form action="userlogin.php" method="POST">
<div class="box">
	<h1>Complaint Form</h1></div>
	<div class="main">
<div id="name"><br><br>
	<h2 class="name">NAME</h2>
<input class="firstname"type="text" name="first-name" required=""><br>
</div>

<h2 class="name">EMAIL</h2>
<input class="email"type="text" name="email" required="">

<h2 class="name">DATE</h2>
<div class="center">
	<input style="height:40px;" name="date1" type="date" value="" required="">
</div>

<h2 class="name">ROOM NO</h2>
<input class="roomno"type="text" name="room_no" required="">

<h2 class="name">COLLEGE NAME</h2>
<select class="option" name="College" required="">
<option value="">--Select--</option>	
<option value="Muthayammal Engineering College(MEC)">Muthayammal Engineering College(MEC)</option>
<option value="Muthayammal College Of Engineering(MCE)">Muthayammal College Of Engineering(MCE)</option>
</select>

<h2 class="name">DEPARTMENT</h2>
<select class="dept" name="department" required="">
<option value="">--Select--</option>	
<option value="Mechanical Engineering">Mechanical Engineering</option>
<option value="Information Technology">Information Technology</option>
<option value="Electronics And Communication Engineering">Electronics And Communication Engineering</option>
<option value="Electrical And Electronics Engineering">Electrical And Electronics Engineering</option>
<option value="Medical Electronics">Medical Electronics</option>
<option value="Computer Science And Engineering">Computer Science And Engineering</option>
<option value="Civil Engineering">Civil Engineering</option>
<option value="Chemical Engineering">Chemical Engineering</option>
<option value="Bio Medical Engineering">Bio Medical Engineering</option>
<option value="Artificial Intelligence And Data Science">Artificial Intelligence And Data Science</option>
<option value="Bio Technology">Bio Technology</option>
<option value="Cyber Security">Cyber Security</option>
</select>

<h2 class="name">COMPLAINT BOX</h2>
<input class="complaint"type="text" name="Complaint" required="">
<div class="submit">
<button type="Submit" name="submit">SUBMIT</button></div>
<div class="onclick">
<button onclick = "complaint.php">🠕 Jump Up</button>
</div>
</form>
</body>
</html>

