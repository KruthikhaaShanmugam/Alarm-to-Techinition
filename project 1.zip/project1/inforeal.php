<!DOCTYPE html>
<html>
<Head>
    <title> About us</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device, initial-scale=1.0">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css">
    <link rel="stylesheet" type="text/css" href="css/frontpage.css">
    <style>
      @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400&&display=swap');
*{
  margin:0px;
  padding:0px;
  box-sizing:border-box;
  font-family: 'poppins' , sans-serif;
  background color: white;
}
.section{
  width: 100%;
  min-height: 100vh;
  background-color: #ddd;
}
.container{
  width: 80%;
  display: block;
  margin: auto;
  padding-top: 100px;
}
.content-section{
  float: left;
  width: 55%;
}
.image-section{
  float: right;
  width:40%;
}
.image-section img{
  width: 100%
  height:auto;
}
.content-section.title{
  text-transform:uppercase;
  font-size: 28px;
}
.content-section.content h3{
  margin-top: 20px;
  color: #5d5d5d;
  font-size: 21px;
}
.content-section .content p{
  margin-top: 10px;
  font-family: sans-serif;
  font-size: :18px;
  line-height: 1.5;

}
.content-section .content.button{
  margin-top:20px;
}
.content-section .content .button a{
  background-color: #3d3d3d;
  padding:12px 40px;
  text-decoration: none;
  color:#fff;
  font-size: 15px;
  letter-spacing: 1.5px;
}

.content-section.content .button a:hover{
  background-color:#a52a2a;
  color:#fff;
}
.content-section .social{
  margin-top: 40px;
}
.content-section .social i{
  color:#a52a2a;
  font-size:30px;
  padding:0px 10px; 
}
    </style>
</Head>
<body>
    <b>
      <div class="menu_bar">
      <ul>
        <li class="active"><a  style="font-size:20px; "class="active" href="home.php">HOME</a></li>
        <li><a  style="font-size:20px; " href="inforeal.php">INFO</a></li>
       
        <li><a  style="font-size:20px; " href="#">USER</a>


        <div class="sub_menu1">
          <ul>
            <li> <a   style="font-size:20px; "href="userloginreal.php">LOGIN</a></li>
            <li> <a   style="font-size:20px; "href="usersignup1.php">SIGNUP</a></li>
          </ul>
           <li><a style="font-size:20px;" href="loginadmin.php">ADMIN</a></li>
        </div>
</li></ul>
      </ul><b></p>
  <div class="section">
    <div class="container">
      <div class="content-section">
        <div class="title">
          <h2 style="font-size:40px;">About us</h2>
        </div>
        <div class="content">
        <b>  <h3>Muthayammal Engineering College</h3> </b><p>Autonomous Institution affiliated to Anna University, Chennai, was established in the year 2000 under the aegis of Muthayammal Educational Trust and Research Foundation with the motto to uplift the rural community through Technical Education. The College has grown as a reputed Institution in the past 20 years and progressing with the aim to become Centre of Excellence in Engineering Education, Research and Development.The System in Preparation is moving towards the “GREATNESS IN CAREER GUIDANCE AND PLUPERFECT PLACEMENT”. The Training and Placement Cell is a motivation, for its spatial elements of Interview desk areas
          and Group Discussion corridors that render students a total proficient condition to learn and prepare. An in-houseteam of energetic staff work with a solitary rationale in designing the students to the following period of life by every best mean.</p><br>
          <div class="button">
            <h4><a href="https://mec.edu.in/">Read More</a></h4><br>
          </div>
        </div>
        <div class="social">
          <h2><a href="https://www.facebook.com/MuthayammalEngineeringCollege"><i class="fab fa-facebook-f"></i></a>
          <a href="https://twitter.com/MuthayammalEngg"><i class="fab fa-twitter"></i></a>
          <a href="https://www.instagram.com/mec.edu.in"><i class="fab fa-instagram"></i></a>
          <a href="https://www.linkedin.com/school/muthayammal-engineering-college/"><i class="fab fa-linkedin"></i></a>
          <a href="https://www.youtube.com/channel/UCwXxRq7rKL1mOvDbIbbE03g"><i class="fab fa-youtube"></i></a></h2>
      </div>
    </div></div></div>
    
      <div class="section">
    <div class="container">
      <div class="content-section">
        <div class="title"> 
        <h2 style="font-size:40px;">About us</h2>
        </div>
        <div class="content">
         <b> <h3>Muthayammal College Of Engineering</h3><b> <p>Muthayammal College of Engineering was established with a vision to impart high quality Engineering Education. The Institution is affiliated to Anna University and approved by All India Council for Technical Education (AICTE). The Institution focuses on Teaching and Learning along with the Student’s participation in co-curricular and extra-curricular activities. The Institution provides conducive atmosphere for the students‘academic growth through cognitive thinking and personality development. The employability skills of the students are enhanced by stimulating with variety of learning opportunities and hands-on training. We, at MCE continually aim to revolutionize the learning environment by creating an enviable knowledge pool of engineering and technology graduates who are accustomed to the current industry requirements.</p><br>
          <div class="button">
            <h4><a href="https://mce.ac.in/">Read More</a></h4><br>
          </div>
        </div>
        <div class="social">
          <h2><a href="https://www.facebook.com/MuthayammalEngineeringCollege"><i class="fab fa-facebook-f"></i></a>
          <a href="https://twitter.com/MuthayammalEngg"><i class="fab fa-twitter"></i></a>
          <a href="https://www.instagram.com/mec.edu.in"><i class="fab fa-instagram"></i></a>
          <a href="https://www.linkedin.com/school/muthayammal-engineering-college/"><i class="fab fa-linkedin"></i></a>
          <a href="https://www.youtube.com/channel/UCwXxRq7rKL1mOvDbIbbE03g"><i class="fab fa-youtube"></i></a></h2>
      </div>
    </div>
  </div>
</body>
</html>