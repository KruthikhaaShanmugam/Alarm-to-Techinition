<!DOCTYPE html>

<html>

<head>
	<link rel="stylesheet" type="text/css" href="css/frontpage.css">

<title>Sign Up</title></head>

<style type="text/css">

*{margin: 0; padding: 0;}

body{background-image:url("https://mec.edu.in/wp-content/uploads/2020/08/banner-2.png"); font-family: sans-serif;}




 </style>

<body>
	   
	<form method="POST">


<div class = "loginbox">

	<img src="https://www.campusoption.com/images/colleges/logos/29_11_17_093355_Logo.jpg" class="images">
<h1>Sign Up</h1>

<p> Email Id : <input type="text" name="email" required="" >

Name : <input type="text" name="name" required="" >

College Name : <select class ="option" type="option" name="clg_name" required=""  >

<option disabled ="disabled" selected="selected"></option>

<option value= "Muthayammal engineering college" > Muthayammal Engineering College </option>

<option value= "Muthayammal college of engineering" > Muthayammal College Of Engineering </option>

</select>

Department : <select class ="option" type="option" name="dept" required="">

<option disabled ="disabled" selected="selected"></option>

<option value="Agriculture Engineering"> Agriculture Engineering</option>

<option value=" Artificial Intelligence and Datascience" > Artificial Intelligence and Datascience </option>

<option value= "Bio Medical Engineering" > Bio Medical Engineering </option>

<option value= "Bio Technology" > Bio Technology </option>

<option value="Chemical Engineering" > Chemical Engineering </option>

<option value= "Civi Engineering" > Civil Engineering </option>

<option value= "Computer science and Engineering" > Computer science and Engineering </option>

<option value="Cyber Security" > Cyber Security </option>

<option value= "Electronics and Communication Engineering" > Electronics and Communication Engineering </option>

<option value= "Electrical and Electronics Engineering" > Electrical and Electronics Engineering </option>

<option value= "Information Technology" > Information Technology </option>

<option value= "MBA" > MBA </option>

<option value= "MCA" > MCA </option>

<option value= " Medical Electronics" > Medical Electronics </option>

<option value= "Mechanical Engineering" > Mechanical Engineering </option>

<option value= "Robotics and Automation" > Robotics and Automation </option>

<option value= "science and humanities" > science and humanities </option>

</select>

Password : <input type="password" name="password" required="" >

<input type="submit" value="Sign Up" name="signup" >

</p>

</form>

</div>

</body>

</html>