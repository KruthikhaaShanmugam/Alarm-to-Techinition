<?php
$connection = mysqli_connect("localhost","root","","learning");

if(isset($_POST['submit']))
{
    $name = $_POST['first-name'];
    $email = $_POST['email'];
    $date = date('Y-m-d',strtotime($_POST['date1']));
    $roomno = $_POST['room_no'];
    $college = $_POST['College'];
    $department = $_POST['department'];
    $complaint = $_POST['Complaint'];

    $query = "insert into php1(`first-name`,`email`,`date1`,`room_no`,`College`,`department`,`Complaint`) VALUES ('$name','$email','$date','$roomno','$college','$department','$complaint') ";
    $query_run = mysqli_query($connection,$query);
   if($query_run){
     include("script.php");
   }
   

}
  
?>
