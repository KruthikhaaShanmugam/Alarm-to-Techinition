<?php 

 include("usersignupcon.php");


    if($_SERVER['REQUEST_METHOD'] == "POST")
    {
        //something was posted
        $email = $_POST['email'];
        $password = $_POST['password'];

        if(!empty($email) && !empty($password))
        {

            //read from database
            $query = "select * from registration1 where email = '$email' limit 1";
            $result = mysqli_query($link, $query);

            if($result)
            {
                if($result && mysqli_num_rows($result) > 0)
                {

                    $guru_data = mysqli_fetch_assoc($result);
                    
                    if($guru_data['password'] === $password)
                    {

                        $_SESSION['password'] = $guru_data['password'];
                       header ("location: complaint form.php");

                        die;
                    }

                }
            }
                ?>
            <script>alert("wrong username or password ")</script>
            <?php
        }else
        {
                ?>
            <script>alert("wrong username or password")</script>
            <?php
        }
    }

 ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="css/frontpage.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js" charset="utf-8"></script>
    <style>
      *{
  margin: 0;
  padding: 0;
  text-decoration: none;
  font-family: montserrat;
  box-sizing: border-box;
}

body{
  min-height: 100vh;
  background-image: linear-gradient(120deg,#3498db,#8e44ad);
}

.admin-form{
  width: 350px;
  background: white;
  height: 450px;
  padding: 50px 40px;
  border-radius: 30px;
  position: absolute;
  left: 50%;
  top: 60%;
  transform: translate(-50%,-50%);
  border:2px solid black;
}

.admin-form h2{
  text-align: center;
  margin-bottom: 60px;
}

.txtb{
  border-bottom: 2px solid #adadad;
  position: relative;
  margin: 30px 0;
}

.txtb input{
  font-size: 15px;
  color: #333;
  border: none;
  width: 100%;
  outline: none;
  background: none;
  padding: 0 5px;
  height: 40px;
}

.txtb span::before{
  content: attr(data-placeholder);
  position: absolute;
  top: 60%;
  left: 5px;
  color: black;
  transform: translateY(-50%);
  z-index: -1;
  transition: .5s;
}

.txtb span::after{
  content: '';
  position: absolute;
  width: 0%;
  height: 2px;
  background: linear-gradient(120deg,#3498db,#8e44ad);
  transition: .5s;
}

.focus + span::before{
  top: -5px;
}
.focus + span::after{
  width: 100%;
}

.logbtn{
  display: block;
  width: 100%;
  height: 40px;
  border: none;
  background: linear-gradient(120deg,#3498db,#8e44ad,#3498db);
  background-size: 200%;
  color: #fff;
  outline: none;
  cursor: pointer;
  transition: .9s;
}

.logbtn:hover{
  background-position: right;
}

.bottom-text{
  margin-top: 40px;
  text-align: center;
  font-size: 17px;
}
    </style>
  </head>
  <body>

     <B>   <div class="menu_bar">
      <ul>
        <li class="active"><a  style="font-size:20px;"class="active" href="home.php">HOME</a></li>
        <li><a style="font-size:20px;"href="inforeal.php">INFO</a></li>
       
        <li><a style="font-size:20px;"href="#">USER</a>


        <div class="sub_menu1">
          <ul>
            <li> <a style="font-size:20px;" href="userloginreal.php">LOGIN</a></li>
            <li> <a style="font-size:20px;" href="usersignup1.php">SIGNUP</a></li>
          </ul>
           <li><a  style="font-size:20px;"href="loginadmin.php">ADMIN</a></li>
        </div>
</li></ul>
      </ul></B>
    
  

      <form method="POST" class="admin-form">
        <h2 style="color:black;">User Login</h2>

        <div class="txtb">
          <input type="text" name="email">
          <span data-placeholder="EMAIL"></span>
        </div>

        <div class="txtb">
          <input type="password" name="password">
          <span data-placeholder="PASSWORD"></span>
        </div>

        <input type="submit" class="logbtn" value="LOGIN" name="submit">


     
        <div class="bottom-text">
          FORGOT  <a href="forgot-password.php">PASSWORD?</a>
        </div>

      </form>

      <script type="text/javascript">

      $(".txtb input").on("focus",function(){
        $(this).addClass("focus");
      });

      $(".txtb input").on("blur",function(){
        if($(this).val() == "")
        $(this).removeClass("focus");
      });

      </script>
</body>
</html>



  