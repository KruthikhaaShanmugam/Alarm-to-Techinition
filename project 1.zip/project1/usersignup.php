<?php include("usersignupcon.php"); ?>

<!DOCTYPE html>

<html>

<head>

<title>Sign Up</title></head>

<style type="text/css">

*{margin: 0; padding: 0;}

body{background-image:url("https://mec.edu.in/wp-content/uploads/2020/08/banner-2.png"); font-family: sans-serif;}

.loginbox{
	width: 425px;
	height: 595px;
	background: rgba(0,0, 0, 0.5);
	color:#fff;
	top:50%;
	left:50%;
	position:absolute;
	transform:translate(-50%,-50%);
	box-sizing: border-box;
	padding:80px 50px;

}
.images{
	width: 100px;
	height: 100px;
	border-radius: 50%;
	position: absolute;
	top:-40px;
	left:calc(50% - 50px);
}
h1{
	margin:0;
	padding-bottom: 5px;
	text-align: center;
	font-size: 22px;
}
.loginbox p{
	margin: 0;
	padding: 0;
	font-weight: bold;

}
.loginbox p
{
	font-size: 22px;
	color: dodgerblue;

}
.loginbox input{
	width: 100%;
	padding: 10px 0px;
	margin-bottom: 25px;
	background: #fff;
	bottom: none;
	outline: none;
    font-size:15px;
}

.login input[type="email"], .login input[type="name"], .login input[type="password"];
{
	border:none;
	border-bottom: 1px solid #fff;
	background:transparent;
	outline: none;
	height:40px;
	color: #000;
	font-size: 22px;
}
.loginbox select{
	width: 100%;
	padding: 10px 0px;
	margin-bottom: 25px;
	background: #fff;
	bottom: none;
	outline: none;
    font-size:15px;
}
.loginbox input[type="submit"]
{
	background: transparent;
	border: none;
	outline: none;
	height:40px;
	background:#1c8adb;
	color:#fff;
	padding: 10px 20px;
	font-size:22px;
	border-radius:10px;
}
.loginbox input[type="submit"]:hover
{
    cursor:pointer;
    background:#ffc187;
    color:#000;
    border-radius: 5px;
}


 </style>

<body>
	<form method="POST">


<div class = "loginbox">
<div class= "card-title">
	<img src="https://www.campusoption.com/images/colleges/logos/29_11_17_093355_Logo.jpg" class="images">
<h1>Sign Up</h1>

<?php
   $Msg = "";
   if(isset($_GET['error']))
   {
   	$Msg = "Email Id Already Exists";
   	echo '<div class="alert alert-danger">'.$Msg.'</div>';

   }
?>
</div>
<p> Email Id : <input type="text" name="email" required="" >
Name : <input type="text" name="name" required="" >

College Name : <select class ="option" type="option" name="clg_name" required=""  >

<option disabled ="disabled" selected="selected"></option>

<option value= "Muthayammal engineering college" > Muthayammal Engineering College </option>

<option value= "Muthayammal college of engineering" > Muthayammal College Of Engineering </option>

</select>

Department : <select class ="option" type="option" name="dept" required="">

<option disabled ="disabled" selected="selected"></option>

<option value="Agriculture Engineering"> Agriculture Engineering</option>

<option value=" Artificial Intelligence and Datascience" > Artificial Intelligence and Datascience </option>

<option value= "Bio Medical Engineering" > Bio Medical Engineering </option>

<option value= "Bio Technology" > Bio Technology </option>

<option value="Chemical Engineering" > Chemical Engineering </option>

<option value= "Civi Engineering" > Civil Engineering </option>

<option value= "Computer science and Engineering" > Computer science and Engineering </option>

<option value="Cyber Security" > Cyber Security </option>

<option value= "Electronics and Communication Engineering" > Electronics and Communication Engineering </option>

<option value= "Electrical and Electronics Engineering" > Electrical and Electronics Engineering </option>

<option value= "Information Technology" > Information Technology </option>

<option value= "MBA" > MBA </option>

<option value= "MCA" > MCA </option>

<option value= " Medical Electronics" > Medical Electronics </option>

<option value= "Mechanical Engineering" > Mechanical Engineering </option>

<option value= "Robotics and Automation" > Robotics and Automation </option>

<option value= "science and humanities" > science and humanities </option>

</select>

Password : <input type="password" name="password" required="">

<input type="submit" value="Sign Up"name="signup" >

</p>

</form>

</div>


</body>

</html>
