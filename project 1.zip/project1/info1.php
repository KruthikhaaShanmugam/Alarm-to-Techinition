<! DECOTYPE html>
<html>
<head>
	  <meta name="viewport" content="width=device-width, initial-scale=1.0">
	 <link rel="stylesheet" href="css/frontpage.css">
	  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
	


<title>main
</title>
</head>
<body>

	  
      
     
      <div class="menu_bar">
      <ul>
        <li class="active"><a class="active" href="#">HOME</a></li>
        <li><a href="info1.php">INFO</a></li>
        <li><a href="#">COMPLIANT</a>

        <div class="sub_menu1">
        	<ul>
        		<li> <a href="complaint form.php">COMPLIANT FORM</a></li>
        		<li> <a href="ADMIN.html">COMPLIANT LIST</a></li>
        	</ul>
        </div>
</li>
        <li><a href="cantactus.php">CONTACT</a></li>
        <li><a href="index.php">LOG OUT</a></li>
      </ul>
    </div>
      <br> <h1>MUTHAYAMMAL </h1>
  <br>
  <img  style="height:500px; width:1270px; " src="image/muthaymmal.jpg"/>

  
  <br>
  <br>
  <br>
  <br>
  <div >
<h1 style="width-right:20px;">About MEC
  <br>
</h1>
<p style="padding:20px; height:1000px; width:800px;">Muthayammal Engineering College, an Autonomous Institution affiliated to Anna University, Chennai, was established in the year 2000 under the aegis of Muthayammal Educational Trust and Research Foundation with the motto to uplift the rural community through Technical Education. The College has grown as a reputed Institution in the past 20 years and progressing with the aim to become Centre of Excellence in Engineering Education, Research and Development
  Muthayammal College of Engineering was established with a vision to impart high quality Engineering Education. The Institution is affiliated to Anna University and approved by All India Council for Technical Education (AICTE). The Institution focuses on Teaching and Learning along with the Student’s participation in co-curricular and extra-curricular activities. The Institution provides conducive atmosphere for the students‘academic growth through cognitive thinking and personality development. The employability skills of the students are enhanced by stimulating with variety of learning opportunities and hands-on training. We, at MCE continually aim to revolutionize the learning environment by creating an enviable knowledge pool of engineering and technology graduates who are accustomed to the current industry requirements

</p>

</div>
    
	

 



</body>
</html>