<!DOCTYPE html>
<html>
<head>
	<title>Complaint Table</title>
	<style type="text/css">
		table {
			border-collapse: collapse;
			width: 100%;
			color: black;
			font-family: monospace;
			font-size: 25px;
			text-align: left;
		}
		th{
			background-color: darkgreen;
			color: white;
		}
		tr:nth-child(even){background-color: #f2f2f2}
	</style>
</head>
<body>
	<table>
		<tr>
			<th>first-name</th>
			<th>email</th>
			<th>date1</th>
			<th>room_no</th>
			<th>College</th>
			<th>department</th>
			<th>Complaint</th>
		</tr>
		<?php
		$conn = mysqli_connect("localhost","root","","learning");
		if($conn-> connect_error){
			die("Connection failed:".$conn-> connect_error);
		}
		$sql = "SELECT first-name, email, date1, room_no, College, department, Complaint from php1";
		$result = $conn-> query($sql);

		if($result-> num_rows > 0){
			while ($row = $result-> fetch_assoc()) {
				echo "<tr><td>". $row["first-name"]."</td><td>". $row["email"]."</td><td>". $row["date1"]."</td><td>". $row["room_no"]."</td><td>". $row["College"]."</td><td>".$row["department"]."</td><td>".$row["Complaint"]."</td></tr>";
			}
			echo "</table>";
		}
		else {
			echo "0 result";
		}
		$conn-> close();


		?>

</body>
</html>