<?php

  require_once("usersignupcon.php");

if(isset($_POST['submit'])){

  $email=$_POST['email'];
  $password=$_POST['password'];

  	$query ="SELECT * FROM registration1 WHERE email = ? AND password = ? LIMIT 1";
    $stmt = $link->prepare($query);
    $result =$stmt->execute([$email , $password]);
    if($result){
      $user=$stmt->fetch();
      $_SESSION['connection']=$user;
       if ($stmt->rowCount() > 0)
         {

        	echo "Login Success";
        }
        else
        {
        	echo "<script>alert('incorrect username or password');</script>";
        }
       }else{
        echo'there were errors while connecting to database.';
       }}
?>

