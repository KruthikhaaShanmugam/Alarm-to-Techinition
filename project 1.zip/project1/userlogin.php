<?php 


   include("usersignupcon.php");


    if($_SERVER['REQUEST_METHOD'] == "POST")
    {
        //something was posted
        $email = $_POST['email'];
        $password = $_POST['password'];

        if(!empty($email) && !empty($password))
        {

            //read from database
            $query = "select * from registration1 where email = '$email' limit 1";
            $result = mysqli_query($link, $query);

            if($result)
            {
                if($result && mysqli_num_rows($result) > 0)
                {

                    $guru_data = mysqli_fetch_assoc($result);
                    
                    if($guru_data['password'] === $password)
                    {

                        $_SESSION['password'] = $guru_data['password'];
                       header ("location: form.php");

                        die;
                    }

                }
            }
            	?>
			<script>alert("wrong username or password ")</script>
			<?php
        }else
        {
            	?>
			<script>alert("wrong username or password")</script>
			<?php
        }
    }

?>



<html>
<head>
<title>Login Form Design</title>
<style type="text/css">
    body
    {
	 margin:0;
	 padding:0;
	 background color: transparent; 
	 background-size:cover;
	 background-image: url(https://mec.edu.in/wp-content/uploads/2020/08/banner-2.png); 
	 background-position: center;
	 font-family: sans-serif;
    }
.loginbox{
	width: 425px;
	height: 595px;
	background: rgba(0,0, 0, 0.5);
	color:#fff;
	top:50%;
	left:50%;
	position:absolute;
	transform:translate(-50%,-50%);
	box-sizing: border-box;
	padding:100px 70px;

}
.images{
	width: 100px;
	height: 100px;
	border-radius: 50%;
	position: absolute;
	top:-40px;
	left:calc(50% - 50px);
}
h1{
	margin:0;
	padding:0 0 20px;
	text-align: center;
	font-size: 22px;
}
.loginbox p{
	margin: 0;
	padding: 0;
	font-weight: bold;

}
.loginbox p
{
	font-size: 22px;
	color: dodgerblue;

}
.loginbox input{
	width: 100%;
	padding: 10px 0px;
	margin-bottom: 10px;
	background: #fff;
	bottom: none;
	outline: none;
    font-size:15px;
}
.login input[type="email"], .login input[type="password"];
{
	border:none;
	border-bottom: 1px solid #fff;
	background:transparent;
	outline: none;
	height:40px;
	color: #000;
	font-size: 22px;
}
.loginbox input[type="submit"]
{
	background: transparent;
	border: none;
	outline: none;
	height:40px;
	background:#1c8adb;
	color:#fff;
	padding: 10px 20px;
	font-size:22px;
	border-radius:10px;
}
.loginbox input[type="submit"]:hover
{
    cursor:pointer;
    background:#ffc187;
    color:#000;
    border-radius: 5px;
}
.loginbox a{
	text-decoration: none;
   
	color:#000;

}
.loginbox a:hover
{
     color: pink;
     text-align: left;
}
 .loginbox a{
	text-decoration: underline;
    font-size: 17px;
	line-height:20px;
	color: #00ffff;

}
.loginbox a:hover{
	{
     text-decoration: underline;
     color:purple;
     text-align: left;
}

 </style>

</head>
<body>
	<div class="loginbox">

	<img src="https://www.campusoption.com/images/colleges/logos/29_11_17_093355_Logo.jpg" class="images">
	<h1>Login Here</h1>

<?php 
        if(!empty($login_err)){
            echo '<div class="alert alert-danger">' . $login_err . '</div>';
        }        
        ?>


	<form method="POST">
	<p>Email</p>
	<input type="text" name="email" placeholder="Enter Email" required=""><br><br>
	<br>
	<p>Password</p>
	<input type="password" name="password"	placeholder="Enter Password" required="" >
	<h4> <a  href="forgetuserlogin.php">Forgot Password?</a></h4>
	<input type="Submit" name="login" Value="Login">
   
<h4>
	<p text align="right" class="Sign-up"><a href="usersignup.php">Sign up</a></p><br>
    
    <p  text align="right"class="Login as Admin"><a href="admin.php">Login as Admin</a></p>
		
	
	</a>
</h4>
</form>
</body>
<html>

