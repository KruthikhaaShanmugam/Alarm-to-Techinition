
<?php
 
  include("connection.php");

if (isset($_POST['login'])) 
  {    
       	$query ="SELECT * FROM `admin_page` WHERE `username` LIKE '$_POST[username]' AND `password` LIKE '$_POST[password]'";
        $result= mysqli_query($link,$query);
        if (mysqli_num_rows($result)==1)
         {
          header("location:Table1.php");
          
       }
       else
        {
        	echo "<script>alert('incorrect username or password');</script>";
        }
       }
     
?>


 

