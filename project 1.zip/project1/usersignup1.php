<?php include("usersignupcon.php"); ?>

<!DOCTYPE html>

<html>

<head>   <link rel="stylesheet"href="css/frontpage.css">
	

<title>Sign Up</title></head>

<style type="text/css">

*{margin: 0; padding: 0;}



<style>
*
{


 font-family: sans-serif;
                box-sizing: border-box;
                margin: 0;
                padding: 0;
            }
 body{
      background-image: linear-gradient(120deg,#3498db,#8e44ad);
 }
            
 
            .form-wrapper{
                position: absolute;
                top: 63%;
                left: 50%;
                transform: translate(-50%, -50%);
                border-radius: 40px;
                width: 400px;
                padding:20px;
                border: 1px solid black;
                background-color:white;
                 
            }
 
            h2{
                color: black;
                text-align: center;
                margin-bottom: 30px;
            }
 
            label{
                color: white;
                font-size: large;
            }
 
            input{
                width: 90%;
                padding: 10px;
                margin: 10px 0px 10px 0;
                background:white;
                border: 2px solid black ;
                border-radius: 5px;
                color: black;
                display: inline-block;
                border-radius: 20px;
            }
             
 
            input[type="submit"]{
                font-size: 20px;
                color: white;
                background: rgba(8, 212, 8, 0.664);
            }
 
            input[type="submit"]:hover{
                cursor: pointer;
                background: rgba(8, 212, 8, 0.815);
            }
 </style>

<body><b>
	 <div class="menu_bar">
      <ul>
        <li class="active"><a style="font-size:20px;"class="active" href="home.php">HOME</a></li>
        <li><a style="font-size:20px;" href="inforeal.php">INFO</a></li>
       
        <li><a style="font-size:20px;" href="#">USER</a>


        <div class="sub_menu1">
          <ul>
            <li> <a style="font-size:20px;" href="userloginreal.php">LOGIN</a></li>
            <li> <a style="font-size:20px;" href="usersignup1.php">SIGNUP</a></li>
          </ul>
           <li><a style="font-size:20px;" href="cantactus.php">CONTACT</a></li>       
          
                         </div>
                


<div class="form-wrapper">
<h2 style="font-size:30px;"> User SignUp</h2>

<?php
   $Msg = "";
   if(isset($_GET['error']))
   {
    $Msg = "Email Id Already Exists <br> Kindly Login";
    echo '<div class="alert alert-danger" style="color:red; text-align:center;">'.$Msg.'</div>';

   }
?>
<form method="POST">
<p> Email Id : <input type="text" name="email" required="" >

Name : <input type="text" name="name" required="" >

College Name : <input type="text" placeholder=" Example - MEC "  name="clg_name" required=""  >



Department : <input type="text" placeholder="Department name"name="dept" required="">



Password : <input type="password" name="password" required="" >

<input type="submit" value="Sign Up" name="signup" >

</p>
             <div class="bottom-text">Existing User : 
          <a href="userloginreal.php ">Login Here</a>
        </div>
</div>


</div>
 </b>

</form>
</body>

</html>