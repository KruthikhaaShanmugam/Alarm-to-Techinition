<script src="sweetalert.min.js"></script>
<?php
 if($query_run)
    { ?>
     '
   <script>
    	swal({
          title: "<?php echo("Submit Successfully"); ?>",
          text: "Thank you for your information ",
          icon: "success",
          button: "OK",
        });
    </script>'
    <?php
}
?>
