

<!DOCTYPE html>
<html>
<head>
<title>Table with database</title>
</head>
<link rel="stylesheet" href="css/bootstrap.min.css">
<style type="text/css">
      .table{
            width: 90%;
            color: teal;
      }
    button{
      width: 95px;
      height:40px;
      float:right;
      background-color: green;
      
    }
    h1,h2{
      text-align: center;
    }
</style>
<body>
       <button  style="color: white" type="submit" name="logout">logout</button>
            <h1 style="color: teal;">MUTHAYAMMAL INSTITUTIONS</h1>
            <h2 style="color: green"> Complaints For Electricians </h2>
       <br>
       <form action="select.php" method="POST">
        <center>
            DATE : <input type="text" name="date1" required><br><br>
            
           <input  type="submit" style="color: teal;"  name="search" value="Search Here">
         </center>
       </form>
      <br>
      <div class="table-responsive">
<table class="table table-bordered" style="border-color: silver:"align="center">
<tr border="5">
<th width="7%" style="background-color: green"><h4 style="color: white">Name</h4></th>
<th width="14%" style="background-color: green"><h4 style="color: white">Email</h4></th>
<th width="7%" style="background-color: green"><h4 style="color: white">Date</h4></th>
<th width="5%" style="background-color: green"><h4 style="color: white">Room N0</h4></th>
<th width="22%" style="background-color: green"><h4 style="color: white">College</h4></th>
<th width="20%" style="background-color: green"><h4 style="color: white">Department</h4></th>
<th width="15%" style="background-color: green"><h4 style="color: white">Complaint</h4></th>
<th width="8%" style="background-color: green"><h4 style="color: white">Status</h4></th>
<th width="8%" style="background-color: green"><h4 style="color: white">Operation</h4></th>
</tr>
</td>


<?php
$conn = mysqli_connect("localhost", "root", "", "learning");
// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT * FROM `php1`";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>".$row["first-name"]."</td>";
            echo "<td>".$row["email"]."</td>";
            echo "<td>".$row["date1"]."</td>";
            echo "<td>".$row["room_no"]."</td>";
            echo "<td> ".$row["College"]."</td>";
            echo "<td>".$row["department"]."</td>";
            echo "<td>".$row["Complaint"]."</td>";
            echo "<td>".$row["Status"]."</td>";
             echo "<td><a class='btn btn-danger' href='updatehomereal.php? em=$row[email] & dt=$row[date1] & rn=$row[room_no]& cl=$row[College] & dp=$row[department] & cp=$row[Complaint] & st=$row[Status]'>Edit</a></td>";
            echo "</tr>";
}
} else { echo "0 results"; }
$conn->close();
?>

</table>
</div>
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</body>
</html>