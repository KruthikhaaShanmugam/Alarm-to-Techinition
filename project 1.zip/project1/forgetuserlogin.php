
<?php
require 'connection.php';

 if (isset($_POST['submit'])) 
    {
        //something was posted
        $email = $_POST['email'];

        if(!empty($email))
        {

            //read from database
            $query = "select * from registration1 where email = '$email' limit 1";
            $result = mysqli_query($link, $query);

            if($result)
            {
                if($result && mysqli_num_rows($result) > 0)
                {

                    $guru_data = mysqli_fetch_assoc($result);
                    
                    if($guru_data['email'] === $email)
                    {

                        $_SESSION['email'] = $guru_data['email'];
                        
                        $sub = 'Reset your password';
                        $rec = 'Email : '. $email ;
                        $msg = 'http://localhost/pro1/changenewpswuser.php';
//$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
                        mail($rec,$sub,$msg); 
                                
                       }  $Msg='<div class= "alert alert-danger" style="color:red;">Message send your email address!</div>';
                             }else{

                                $errMsg='<div class= "alert alert-danger" style="color:red;">Your Email address not found!</div>';
                                
                             }
                         }else{
                                echo"email not found";
                             }
                         }
                     }

                           ?>


<!DOCTYPE html>
<html>
<head>
	<title>Forget Password</title>
</head>
<body>
	<form action="forgetuserlogin.php" method="POST">
    <p>Email</p>
	<input type="text" name="email" placeholder="Enter Email" required=""><br><br>
   <?php
          if (isset($Msg)) {
            echo $Msg;
          }
        ?>
    <?php
          if (isset($errMsg)) {
            echo $errMsg;
          }
        ?><br>
	
    <input type="Submit" name="submit" value="Reset Password">
    </form>		
</body>
</html>