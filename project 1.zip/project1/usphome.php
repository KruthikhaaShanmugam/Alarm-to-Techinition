<?php
   require("PHPMailer/PHPMailerAutoload");
   require("crediantial.php");
?>

<!DOCTYPE html>
<html>
<head>
	<title>Forget Password</title>
</head>
<body>
 <?php
 $con = mysqli_connect("localhost","root","","learning");
 if(isset($_POST['submit'])){
 	$email=$_POST['email'];
 	$query="SELECT * FROM `registration1` WHERE email = '$email'";
 	$result=mysqli_query($con,$query);
 	$count=mysqli_num_rows($result);
 	$data= mysqli_fetch_array($result);
 	$idData=$data['id'];
 	$emailData=$data['email'];
 	$nameData=$data['name'];

    $url = 'http://'.$_SERVER['SERVER_NAME'].'/pro1/changepass.php?id='.$idData.'&email='.$emailData;
    $output ='Hi, please click this link to change your password.<br>'.$url;

 	if($email == $emailData){
       
       $mail = new PHPMailer;

//$mail->SMTPDebug = 3;                               // Enable verbose debug output

$mail->isSMTP();                                      // Set mailer to use SMTP
$mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
$mail->SMTPAuth = true;                               // Enable SMTP authentication
$mail->Username = EMAIL;                 // SMTP username
$mail->Password = PASS;                           // SMTP password
$mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
$mail->Port = 587;                                    // TCP port to connect to

$mail->setFrom(EMAIL, 'localhost');
$mail->addAddress($email, $nameData);     // Add a recipient
//$mail->addAddress('ellen@example.com');               // Name is optional
//$mail->addReplyTo('info@example.com', 'Information');
//$mail->addCC('cc@example.com');
//$mail->addBCC('bcc@example.com');

//$mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
//$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name
$mail->isHTML(true);                                  // Set email format to HTML

$mail->Subject = 'Reset Password: ';
$mail->Body    = $output;
//$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

if(!$mail->send()) {
    echo 'Message could not be sent.';
    echo 'Mailer Error: ' . $mail->ErrorInfo;
} else {
    $Msg = '<div class= "alert alert-success">Message has been sent</div>';
}

 	}
 	else{
 		$errMsg ='<div class= "alert alert-danger">Your Email address not found!</div>';
 	}

 }
?>
	<br><br><br><br><br><br><br>
	<div class="container">
		<?php
          if (isset($Msg)) {
          	echo $Msg;
          }
		?>
		<?php
          if (isset($errMsg)) {
          	echo $errMsg;
          }
		?>
	<form action=" " method="POST">
		<h3>FORGET PASSWORD</h3>
		<hr>
		<div class="col-md-12 " style="width: 40%">
			<div class="form-group">
    <label>Enter Email</label>
	<input type="text" class="form-control" name="email" placeholder="Enter Email" required=""><br><br>
	<br>
	
    <input type="Submit" name="submit" value="Reset Password">
    </form>		
</body>
</html>