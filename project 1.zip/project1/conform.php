<?php
 $connect = mysqli_connect("localhost","root","","learning");
if(isset($_POST['conform']))
{   
  
   $room_no = $_POST['room_no'];
   $Complaint = $_POST['Complaint'];
           
   // mysql query to Update data
   $query = "UPDATE `php1` SET `room_no`='".$room_no."',`Complaint`='".$Complaint."' WHERE `room_no` = '$room_no'";
   
   $result = mysqli_query($connect, $query);
   
   if($result)
   {
        echo '<script type="text/javascript">alert("Submit Successfully")</script>';
   }else{
       echo 'Data Not Updated';
   }
   mysqli_close($connect);
}
?>