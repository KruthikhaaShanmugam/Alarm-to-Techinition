
<!DOCTYPE html>
<html>
<head>
<title>Complaint List</title>
<style type="text/css">
table{
text-align: center;
color:
margin-top:100px;
margin-left: 500px;
}
button{
    margin-left: 750px;
    margin-top: 8px;
    width: 70px;
    height: 30px;
}
</style>
</head>
<body>
<?php

$name=$_POST['first-name'];
$email=$_POST['email'];
$date=$_POST['date1'];
$roomno=$_POST['room_no'];
$cname=$_POST['College'];
$dept=$_POST['department'];
$combox=$_POST['Complaint'];

    echo "<table border=1>
    <tr>
    <th>Name</th>
    <td>$name</td>
    </tr>
     <tr>
    <th>email</th>
    <td>$email</td>
    </tr>
     <tr>
    <th>date</th>
    <td>$date</td>
    </tr>
     <tr>
    <th>roomno</th>
    <td>$roomno</td>
    </tr>
     <tr>
    <th>collegename</th>
    <td>$cname</td>
    </tr>
     <tr>
    <th>department</th>
    <td>$dept</td>
    </tr>
    <tr>
    <th>complaint</th>
    <td>$combox</td>
    </tr>
   

    </table>";
?>
<button onClick="history.go(-1);">Edit</button> <!--Back to edit-->
<form action="conform.php" method="POST">
<input type="submit" name="conform" value="CONFORM">

</form>
</body>
</html>

