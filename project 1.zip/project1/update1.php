<?php
if(isset($_POST['update']))
{   
   $connect = mysqli_connect("localhost","root","","learning");
   $room_no = $_POST['room_no'];
   $Status = $_POST['Status'];
           
   // mysql query to Update data
   $query = "UPDATE `php1` SET `room_no`='".$room_no."',`Status`='".$Status."' WHERE `room_no` = '$room_no'";
   
   $result = mysqli_query($connect, $query);
   
   if($result)
   {
        echo '<script type="text/javascript">alert("Submit Successfully")</script>';
        header("location:Table1.php");
   }else{
       echo 'Data Not Updated';
   }
   mysqli_close($connect);
}
?>