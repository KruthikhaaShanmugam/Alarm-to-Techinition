<?php
include("connection.php");
error_reporting(0);
   $email = $_GET['em'];
   $date = $_GET['dt'];
   $room_no = $_GET['rn'];
   $College = $_GET['cl'];
   $department=$_GET['dp'];
   $complaint = $_GET['cp'];
   $status = $_GET['st'];
?>

<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<link rel="stylesheet" type="text/css" href="css/frontpage.css">
<style type="text/css">
    table{
        background-color: teal;
        color: white;
        border-radius: 20px;
        text-align :center;

    }
    #button{
        background-color: green;
        color: white;
        height: 32px;
        width: 125px;
        border-radius: 25px;
        font-size: 20px;
    }
    body{
        min-height: 100vh;
  text-align: center;
        background :white;
    }
  h2

{
      text-align: center;
    }
 

/* contact page */



</style>

<body>
   <b>     <div class="menu_bar">
      <ul>
        <li class="active"><a style="font-size:20px;" class="active" href="home.php">HOME</a></li>
        <li><a style="font-size:20px;" href="inforeal.php">INFO</a></li>
        <li><a style="font-size:20px;" href="#">COMPLIANT</a>

        <div class="sub_menu1">
            <ul>
                <li> <a style="font-size:20px;" href="complaint form.php">COMPLIANT FORM</a></li>
                <li> <a style="font-size:20px;" href="complainthome.php">COMPLIANT LIST</a></li>
            </ul>
        </div>
</li>
        <li><a style="font-size:20px;" href="cantactus.php">CONTACT</a></li>
        <li><a style="font-size:20px;" href="home.php">LOG OUT</a></li>
      </ul>
    </div>
   <br><br><br><br><br>

    <form action="" method="GET">
       
      <table border="1" bgcolor="black" align="center" cellspacing="20px">

        
<h2>Update Status</h2>
          <tr>
              <td>Email Id</td>
              <td><input type="text" name="email" value="<?php echo "$email" ?>" required></td>
          </tr>
            <tr>
              <td>Date</td>
              <td><input type="text" name="date1" value="<?php echo "$date" ?>"  required></td>
          </tr>
            <tr>
              <td>Room Number</td>
              <td><input type="text" name="room_no" value="<?php echo "$room_no" ?>"  required></td>
          </tr>
            <tr>
              <td>College</td>
              <td><input type="text" name="College" value="<?php echo "$College" ?>"  required></td>
          </tr>
            <tr>
              <td>Department</td>
              <td><input type="text" name="department" value="<?php echo "$department" ?>"  required></td>
          </tr>
          <tr>
              <td>Complaint</td>
              <td><input type="text" name="Complaint" value="<?php echo "$complaint" ?>"  required></td>
          </tr>
          <tr>
              <td>Status</td>
              <td><input type="text" name="Status" value="<?php echo "$status" ?>"  required></td>
          </tr>
          <tr>
          <td colspan="2" align="center"><input type="submit" id="button" name="update" value="UPDATE">
          </a>
           </td>   
          </tr>





      </table>  

    </form>

</body>
</html>
<<?php 
if($_GET['update'])
{
    $email1 = $_GET['email'];
    $date1 = $_GET['date1'];
    $roomno1 = $_GET['room_no'];
    $college1 = $_GET['College'];
    $department1 = $_GET['department'];
    $complaint1 = $_GET['Complaint'];
    $status1 = $_GET['Status'];

   $query ="UPDATE `php1` 
SET `Status` = '$status1'
WHERE
   `room_no` = '$roomno1' AND
   `date1` = '$date1'";

   // $query = "UPDATE `php1` SET  `Status`='$status1'  WHERE `room_no` = 'roomno1' AND `date1` = '$date1'  ";
    $data = mysqli_query($link,$query);

    if($data){
        echo "<script>alert('Record Updated')</script>";
        ?>
        <META HTTP-EQUIV="Refresh" CONTENT ="0; URL= http://localhost/pro1/complaintlist.php">
        <?php

    }else{
        echo "<font color='red'>Failed to update Record<font>";
    }
   


}
 ?>

























