<!DOCTYPE html>
<html>
    <head>
        <title> PHP UPDATE DATA </title>
        <link rel="stylesheet" type="text/css" href="css/stu.css">
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>
        <div class="box">
            <h1>Update Status!!!</h1>
        <form action="update.php"method="POST">
            Room Number: <input class="room no" type="text" name="room_no" required><br><br>
            Status:<input class="status" type="text" name="Status" required><br><br>
            <div class="submit">
    <button type="Submit">UPDATE</button></div>

</div>
        </form>
    </div>
    </body>
</html>