<?php
 include("connection.php");

if($_GET['update'])
{   
   
   $email      = $_GET['email'];
   $date       = $_GET['date1'];
   $room_no    = $_GET['room_no'];
   $clg        = $_GET['College'];
   $dept       = $_GET['department'];
   $Complaint  = $_GET['Complaint'];
   $status     = $_GET['Status'];
           
   // mysql query to Update data
   $query = "UPDATE `php1` SET `email`='$email',`date1`='$date' ,`room_no`='$room_no',`College`='$clg',`department`='$dept',`Complaint`='$Complaint',`Status`='$status'  WHERE  `room_no` = '$room_no' ,  `date1` = '$date' ";
   
   $result = mysqli_query($link, $query);
   
   if($result)
   {
        echo '<script type="text/javascript">alert("Submit Successfully")</script>';
        header("location:complaintlist.php");
   }else{
       echo 'Data Not Updated';
   }
   mysqli_close($link);
}
?>
