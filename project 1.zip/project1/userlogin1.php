<?php 


   include("usersignupcon.php");


    if($_SERVER['REQUEST_METHOD'] == "POST")
    {
        //something was posted
        $email = $_POST['email'];
        $password = $_POST['password'];

        if(!empty($email) && !empty($password))
        {

            //read from database
            $query = "select * from registration1 where email = '$email' limit 1";
            $result = mysqli_query($link, $query);

            if($result)
            {
                if($result && mysqli_num_rows($result) > 0)
                {

                    $guru_data = mysqli_fetch_assoc($result);
                    
                    if($guru_data['password'] === $password)
                    {

                        $_SESSION['password'] = $guru_data['password'];
                       header ("location: complaint form.php");

                        die;
                    }

                }
            }
                ?>
            <script>alert("wrong username or password ")</script>
            <?php
        }else
        {
                ?>
            <script>alert("wrong username or password")</script>
            <?php
        }
    }

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Login Form </title>

    <link rel="stylesheet" href="style.css">
    <style>
    	body{

    background-color:lightblue;

    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;

}



.loginbox{

    width: 350px;

    height: 420px;

    background: black;

    color: pink;

    margin: 70px auto;

    border-radius: 10px;

}



.logo{

    width: 100px;

    height:120px;

    position: relative;

    top: -50px;

    left: calc(50% - 50px);

}



h1{

    text-align: center;

    margin-top: -0px;

}

label{

    font-size: 18px;

    display: block;

    margin-left: 40px;

}

input{

    width: 80%;

    margin: 0 0 20px 20px;

}

input[type="text"],input[type="password"]{

    border: none;

    background: transparent;

    border-bottom: 1px solid #fff;

    height: 40px;

    outline: none;

    color: white;

    font-size: 16px;

}

input[type="submit"]{

    border: none;

    outline: none;

    height: 40px;

    border-radius: 20px;

    background: #fb2525;

    color: white;

    font-size: 20px;

    cursor: pointer;

}

a{

    text-decoration: none;

    color: blue;

    margin-left: 30%;

}

input[type="submit"]{

    display: block;
  width: 85%;
  height: 50px;
  border: none;
  background: linear-gradient(120deg,#3498db,#8e44ad,#3498db);
  background-size: 200%;
  color: #fff;
  outline: none;
  cursor: pointer;
  transition: .9s;

}

.bottom-text{
  margin-top: 30px;
  text-align: center;
  font-size: 13px;
}
    </style>

</head>

<body>

    <div class="loginbox">

    
<br><br>
        <h1> LOGIN</h1>

        <form method="POST">

          

            <input type="text" name="email" placeholder=" Email" required >

            <br><br>

            <input type="password" name="password" placeholder=" Password" required>
            <br><br>

            <input type="submit" value="LOGIN" name="submit">

       
        <div class="bottom-text">
           <a href="#">FORGOT PASSWORD?</a>
        </div>

        </form>


    </div>

</body>

</html>
