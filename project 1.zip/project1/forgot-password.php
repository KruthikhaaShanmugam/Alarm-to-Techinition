 
<?php
require 'connection.php';

 if (isset($_POST['submit'])) 
    {
        //something was posted
        $email = $_POST['email'];

        if(!empty($email))
        {

            //read from database
            $query = "select * from registration1 where email = '$email' limit 1";
            $result = mysqli_query($link, $query);

            if($result)
            {
                if($result && mysqli_num_rows($result) > 0)
                {

                    $guru_data = mysqli_fetch_assoc($result);
                    
                    if($guru_data['email'] === $email)
                    {

                        $_SESSION['email'] = $guru_data['email'];
                        
                        $sub = 'Reset your password';
                        $rec = 'Email : '. $email ;
                        $msg = 'http://localhost/pro1/forgetpswadmin.php';
//$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
                        mail($rec,$sub,$msg); 

                       }else {
                                    echo 'Message not sent';
                                  }
                             }else{

                                $errMsg='<div class= "alert alert-danger" style="color:red;">Your Email address not found!</div>';
                                
                             }
                         }else{
                                echo"email not found";
                             }
                         }
                     }

                           ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Forgot Password</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body >
    <div class="container">
        <div class="row">
            <div class="col-md-4 offset-md-4 form">
                <form action="forgot-password.php" method="POST" autocomplete="">
                    <h2 class="text-center">Forgot Password</h2>
                    <p class="text-center">Enter your email address</p>
                  
                        
    <?php
          if (isset($errMsg)) {
            echo $errMsg;
          }
        ?><br>
                
                    <div class="form-group">
                        <input class="form-control" type="email" name="email" placeholder="Enter email address" required>
                    </div>
                    <div class="form-group">
                        <input class="form-control button" type="submit" name="submit" value="Continue">
<br>                   <p>  Click here to go back :
     <a href="home.php">HOME</a></p>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
</body>
</html>