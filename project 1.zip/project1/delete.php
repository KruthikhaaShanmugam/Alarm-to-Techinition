<?php 
	$con=new mysqli("localhost","root","","learning");
	$room_no = $_GET['rn'];
	$sql="DELETE FROM `php1` WHERE room_no = '$room_no'";
	$data = mysqli_query($con,$sql);

	if($data)
	{
	echo '<h3 style ="color:teal"> Your Record Deleted Successfully </h3>';
	}
	else{
		echo '<h3> Your Record Deleted Failure</h3>';
	}
?>