
<?php
  $conn_db = mysql_connect("localhost","root","") or die();
  $sel_db = mysql_select_db("learning",$conn_db) or die();
  if(isset($_POST['submit']))
  {
  $old_pass=$_POST['old_pass'];
  $new_pass=$_POST['new_psw'];
  $re_pass=$_POST['con_psw'];
  $chg_pwd=mysql_query("select * from admin_page where id='1'");
  $chg_pwd1=mysql_fetch_array($chg_pwd);
  $data_pwd=$chg_pwd1['password'];
  if($data_pwd==$old_pass){
  if($new_pass==$re_pass){
    $update_pwd=mysql_query("update admin_page set password='$new_pass' where id='1'");
    echo "<script>alert('Update Sucessfully'); window.location='admin.php'</script>";
  }
  else{
    echo "<script>alert('Your new and Retype Password is not match'); window.location='admin.php'</script>";
  }

  }
  else
  {
  echo "<script>alert('Your old password is wrong'); window.location='admin.php'</script>";
  }}
?>
