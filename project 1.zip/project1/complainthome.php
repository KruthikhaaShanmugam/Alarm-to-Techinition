
<html>
<head><form method="POST" action="complaintlist.php">
	<link rel="stylesheet" type="text/css" href="css/frontpage.css">
	<style type="text/css">
		*{
			margin:0;            
			padding:0;
		}
		body
		{
			background-color:lightblue;
		}

.sidebar {
  height: 100%;
  width: 0;
  position: fixed;
  z-index: 1;
  top: 0;
  right: 0;
  background-color: dodgerblue;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 60px;

}

.sidebar a {
	
  padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 25px;
  color: orange;
  display: block;
  transition: 0.3s;
}

.sidebar a:hover {
  color: #fff;
}

.sidebar .closebtn {
  position: absolute;
  top: 0;
  right: 25px;
  font-size: 36px;
  margin-left: 50px;
}

.openbtn {
  right:0px;	
  font-size: 20px;
  cursor: pointer;
  background-color: black
  color: white;
  padding: 10px 15px;
  border: none;
}

.openbtn:hover {
  background-color: lightblue;
}

#main {
  transition: margin-right .5s;
  padding: 16px;
}


@media screen and (max-height: 450px) {
  .sidebar {padding-top: 15px,}
  .sidebar a {font-size: 18px;}

}
		body{
			
			background-color: white;
			background-position: center;
			background-size:cover;
			font-family:bahnschrift;
			margin-top:40px;
		}
		.box {
			width: 850px;
			border:3px solid black;
			margin:auto;
			color: black;
			padding: 10px 0px 10px 0px;
			text-align: center;                              
			border-radius: 15px 15px 0px 0px;
			background-color: ;
		}
		.main
		{border:3px solid black;
			background-color:
 ;
			width: 850px;
			margin: auto;
		}
		form
		{
			padding: -25px;
		}
		#name
		{
			width: 100%;
			height:100px;
		}
		.name{
			margin-left: 75px;
			margin-top: 7px;
			width: 125px;
			color: black;
			font-size: 23px;
			font-weight: 700;
		}
		.firstname
		{
			position: relative;
			left: 250px;
			top:-34;
			line-height: 35px;
			border-radius: 6px;
			padding: 0 22px;
			font-size:16px;
		}
		.email
		{
			position: relative;
			left: 250px;
			top:-37;
			line-height: 35px;
			width: 532px;
			border-radius: 6px;
			padding: 0 22px;
			font-size:16px;
			color: #555;
		}
		.center {	
					position: relative;
			        left: -100px;
			        top:-34;
			        line-height: 75px;
			        font-size:16px;
	  				text-align: center;
				}


		.roomno
		{
			position: relative;
			left: 250px;
			top:-37;
			line-height: 35px;
			width: 532px;
			border-radius: 6px;
			padding: 0 22px;
			font-size:16px;
			color: #555;
		}
		.option
		{
			position: relative;
			left: 250px;
			top:-37;
			line-height: 40px;
			width: 532px;
			border-radius: 6px;
			padding: 0 22px;
			font-size:24px;
			color: #555;
			outline: none;
			overflow: hidden;
		}
		.dept
		{
			position: relative;
			left: 250px;
			top:-27;
			line-height: 45px;
			width: 532px;
			border-radius: 6px;
			padding: 0 22px;
			font-size:24px;
			color: #555;
			outline: none;
			overflow: hidden;
		}
		#textarea
		{
			margin-left: 25px;
			color: white;
		}
		.Complaint
		{
			position: relative;
			left: 250px;
			top:-37;
			line-height: 50px;
			width: 532px;
			border-radius: 6px;
			padding: 0 22px;
			font-size:16px;
			color: #555;
		}
		input[type='submit']
		{
			background-color:#339933 ;
			display:block;
			margin: 20px 0px 0px 20px;
			text-align: center;
			border-radius: 12px;
			font-family:bahnschrift;
			border: 2px solid #366473;
			padding: 12px 58px;
			font-size:24px;
			outline: none;
			color: white;
			cursor: pointer;
			transition: 0.25px;
		    position: relative;
			left: 350px;
			top:-34;
			line-height: 35px;
			border-radius: 6px;
			padding: 7 35px;
			font-size:16px;
		}


	</style>
</head>
<body >
	<div class="menu_bar">
      <ul>
        <li class="active"><a style="font-size:20px;" class="active" href="home.php">HOME</a></li>
        <li><a style="font-size:20px;" href="infolist.php">INFO</a></li>
        <li><a style="font-size:20px;" href="#">COMPLAINT</a>

        <div class="sub_menu1">
        	<ul>
        		<li> <a style="font-size:20px;" href="complaint form.php">COMPLAINT FORM</a></li>
        		<li> <a style="font-size:20px;" href="complainthome.php">COMPLAINT LIST</a></li>
        	</ul>
        </div>
</li>
        <li><a style="font-size:20px;" href="cantactus.php">CONTACT</a></li>
        <li><a style="font-size:20px;" href="index.php">LOG OUT</a></li>
      </ul>
    </div>
      


<br><br>

  <b>  <div class="box">
    	<h2 style="font-size:30px color: white;">MUTHAYAMMAL INSTITUTIONS</h2>
    	<h2 style="font-size:30px color: white;">Complaint List</h2></div>
    	<div class="main">
    	<form>
    <div id="name"><br><br>
    	<h2 class="name">NAME</h2>
    <input class="firstname"type="text" name="first-name" required><br>
     </div>
     <h2 class="name">COLLEGE NAME</h2>
    <select class="option" name="College" required>
    	<option>--None--</option>
        <option>Muthayammal Engineering College (MEC)</option>
        <option>Muthayammal College Of Engineering (MCE)</option>
    </select>
    
    <h2 class="name">DEPARTMENT</h2>
    <select class="dept" name="department" required>
    	<option>--None--</option>
        <option>Mechanical Engineering</option>
        <option>Information Technology</option>
        <option>Electronics And Communication Engineering</option>
        <option>Electrical And Electronics Engineering</option>
        <option>Medical Electronics</option>
        <option>Computer Science And Engineering</option>
        <option>Civil Engineering</option>
        <option>Chemical Engineering</option>
        <option>Bio Medical Engineering</option>
        <option>Artificial Intelligence And Data Science</option>
        <option>Bio Technology</option>
        <option>Cyber Security</option>
    </select>
  <br><br>
    <div class="submit">
    <input type="submit" name="search" value="SUBMIT"></div>

</div></b>
</body>
</form>
</html>