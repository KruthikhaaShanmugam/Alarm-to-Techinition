
<! DECOTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="stylesheet" href="css/frontpage.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
    
  <style>
    body
    {
      background-color:lightblue;

    }
    vid
  
    
   h1 {
  font-family:Arial;
  text-align:center;
  color:white;
  text-shadow:1px 1px 2px black, 0 0 25px blue, 0 0 5px darkblue;
  background-color:lightblue;
  font-size: 60px;
}
.slider
{
width:1530px;
height:500px;
position:relative;
overflow:hidden;

}
.img
{
width:1530px;
height:500px;
position: absolute;
animation:slide 10s infinite;
opacity:0;
}
@keyframes slide
{
  10%{opacity:1;}
  20%{opacity:0;}
}
img:nth-child(0){animation-delay: 5s;}
img:nth-child(1){animation-delay: 5s;}


  </style>




<title>HOME
</title>
</head>
<body>
  <h1 style="font-size:50px;">
  ALARM TO TECHNICIANS </h1>
  
   <B>   <div class="menu_bar">
      <ul>
        <li class="active"><a  style="font-size:20px;" class="active" href="home.php">HOME</a></li>
        <li><a  style="font-size:20px;" href="inforeal.php">INFO</a></li>
       
        <li><a  style="font-size:20px;" href="#">USER</a>


        <div class="sub_menu1">
          <ul>
<h3><li> <a style="font-size:20px;"  href="userloginreal.php">LOGIN</a></li></h3>
            <li> <a style="font-size:20px;"  href="usersignup1.php">SIGNUP</a></li>
          </ul>
           <li><a style="font-size:20px;"  href="loginadmin.php">ADMIN</a></li>
        </div>
</li></ul>
      </ul></B>
<b>
    <p style ="font-size:40px;  text-align: center"> MUTHAYAMMAL ENGINEERING COLLEGE</p>   
    <p style ="font-size:20px; text-align: center"> An Autonomous Institution</p>
     <p style="font-size:20px;text-align: center"> Approved by AICTE|Affiliated to Anna Unviersity</p>
     <p style ="font-size:40px;  text-align: center"> &</p>
     <p style ="font-size:40px;  text-align: center"> MUTHAYAMMAL COLLEGE OF ENGINEERING</p>
      <p style="font-size:20px;text-align: center"> Approved by AICTE,New Delhi|Affiliated to Anna Unviersity</p>

     <br>
     <br><br><BR><BR>
   </b>
      <div class="slider">
             
        <img  class="img" src="image/placement.jpg"/>
        <img   class="img" src="image/muthaymmal.jpg"/>
     
    </div>

 



</body>
</html>