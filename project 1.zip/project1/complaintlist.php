
<?php
if(isset($_POST['search']))
{
    $name = $_POST['first-name'];
    $clg_name = $_POST['College'];
    $department = $_POST['department'];
    // search in all table columns
    // using concat mysql function
    $query = "SELECT * FROM `php1` WHERE CONCAT(`Id`, `first-name`, `email`, `date1`, `room_no`, `College`, `department`, `Complaint`, `Status`) LIKE '%".$name."%'" ;
    $search_result = filterTable($query);
    
}
 else {
    $query = "SELECT * FROM `php1`";
    $search_result = filterTable($query);
}

// function to connect and execute the query
function filterTable($query)
{
    $connect = mysqli_connect("localhost", "root", "", "learning");
    $filter_Result = mysqli_query($connect, $query);
    return $filter_Result;
}

?>




<!DOCTYPE html>
<html>
    <head>
        <title> SELECT DATA </title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="css/frontpage.css">
<style type="text/css">
      .table{
            width: 100%;
            color: teal;
      }
      .table-responsive
      {
        border:2px solid black;
      }
</style>
</head>
    <body>
   <b>     <div class="menu_bar">
      <ul>
        <li class="active"><a style="font-size:20px;" class="active" href="home.php">HOME</a></li>
        <li><a style="font-size:20px;" href="inforeal.php">INFO</a></li>
        <li><a style="font-size:20px;" href="#">COMPLAINT</a>

        <div class="sub_menu1">
            <ul>
                <li> <a style="font-size:20px;" href="complaint form.php">COMPLAINT FORM</a></li>
                <li> <a style="font-size:20px;" href="complainthome.php">COMPLAINT LIST</a></li>
            </ul>
        </div>
</li>
        <li><a style="font-size:20px;" href="cantactus.php">CONTACT</a></li>
        <li><a style="font-size:20px;" href="home.php">LOG OUT</a></li>
      </ul>
    </div>
      



 <center>
      <div class="container">
            <h2 style="color: teal;">MUTHAYAMMAL INSTITUTIONS</h2>
            <h2 style="color: green;"> Complaint For Electrician </h2>
      </div>
      <br>
      </center>
             
      <div class="table-responsive"><table class="table table-bordered" style="border-color: black;"align="center">
<tr border="5">
<th width="10%" style="background-color: #00FFFF"><h4 style="color: black">Name</h4></th>
<th width="14%" style="background-color:#00FFFF"><h4 style="color: black">Email</h4></th>
<th width="9%" style="background-color:#00FFFF"><h4 style="color: black">Date</h4></th>
<th width="7%" style="background-color: #00FFFF"><h4 style="color: black">Room no</h4></th>
<th width="25%" style="background-color: #00FFFF"><h4 style="color: black">College</h4></th>
<th width="20%" style="background-color: #00FFFF"><h4 style="color:black">Department</h4></th>
<th width="30%" style="background-color:#00FFFF"><h4 style="color: black">Complaint</h4></th>
<th width="13%" style="background-color: #00FFFF"><h4 style="color: black">Status</h4></th>
<th width="8%" style="background-color: #00FFFF"><h4 style="color: black">Operation</h4></th>


</tr>
 <?php while($row = mysqli_fetch_array($search_result)):?>
                <tr>
                    <td><?php echo $row['first-name'];?></td>
                    <td><?php echo $row['email'];?></td>
                    <td><?php echo $row['date1'];?></td>
                    <td><?php echo $row['room_no'];?></td>
                    <td><?php echo $row['College'];?></td>
                    <td><?php echo $row['department'];?></td>
                    <td><?php echo $row['Complaint'];?></td>
                    <td><?php echo $row['Status'];?></td>
                    <?php echo "<td><a class='btn btn-danger' href='updatehome.php? em=$row[email] & dt=$row[date1] & rn=$row[room_no]& cl=$row[College] & dp=$row[department] & cp=$row[Complaint] & st=$row[Status]'>Edit</a></td>";?>
                </tr>
                <?php endwhile;?></b>
    </form>
    </body>
</html>