<script src="sweetalert.min.js"></script>

<?php
  if (isset($_POST['login']))
    { ?>
     
   '<script>
    	swal({
          title: "<?php echo("Submit Successfully"); ?>",
          text: "Thank you for your information ",
          icon: "success",
          button: "OK",
        });
    </script>'
    <?php
}
?>
