
<?php

session_start();

include("connection.php");

if (isset($_POST['signup'])) {
	$email     = mysqli_real_escape_string($link,$_POST['email']);
	$name      = mysqli_real_escape_string($link,$_POST['name']);
	$clg_name  = mysqli_real_escape_string($link,$_POST['clg_name']);
	$dept      = mysqli_real_escape_string($link,$_POST['dept']);
	$password  = mysqli_real_escape_string($link,$_POST['password']);

	$query = "SELECT * FROM registration1 WHERE email='$email'";
	$result = mysqli_query($link,$query);

	$emailcount = mysqli_num_rows($result);

	if($emailcount>0)
	{
		header("location:usersignup1.php?error");

	}
				
	else{

		$insertquery = "INSERT INTO  registration1 (email, name, clg_name, dept, password) VALUES ('$email', '$name', '$clg_name', '$dept', '$password')";
		$iquery = mysqli_query($link,$insertquery);

		if($iquery)
		{
             header("location:userloginreal.php");
		}else{
			?>
			<script>alert("no connection")</script>
			<?php
			
		}

	}
}
?>